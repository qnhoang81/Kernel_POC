/* This file is auto generated, version 131 */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#131 Mon Feb 27 02:14:51 EST 2012"
#define LINUX_COMPILE_TIME "02:14:51"
#define LINUX_COMPILE_BY "qnhoang81"
#define LINUX_COMPILE_HOST "qnhoang81-laptop"
#define LINUX_COMPILE_DOMAIN
#define LINUX_COMPILER "gcc version 4.6.1 (Buildroot 2011.08) "
