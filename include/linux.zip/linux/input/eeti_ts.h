#ifndef LINUX_INPUT_EETI_TS_H
#define LINUX_INPUT_EETI_TS_H

struct eeti_ts_platform_data {
	unsigned int irq_active_high;
};

#endif /* LINUX_INPUT_EETI_TS_H */

